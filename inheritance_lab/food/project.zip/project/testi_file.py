from project.food import Food
from project.fruit import Fruit

food = Food("23.10.2008")
fruit = Fruit(20)
print(food.expiration_date)
print(fruit.expiration_date)
print(food.expiration_date)